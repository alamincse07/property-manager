<?php if($msg!=''): echo '<div class="success">'.$msg.'</div>'; endif;?>
    <form method='post' action='' enctype="multipart/form-data">
       <div id="add_form"> 
		<?php
			//Show Flash Message
			if($msg = $this->session->flashdata('flash_message'))
			{
				echo $msg;
			}
		?>		
		<table cellpadding="5" cellspacing="5">
            <tbody>
			<tr>
				<th>Add Neighborhood Photographer:</th>
			</tr>
			
                <tr>
                    <th>ciudad </th>
                    <td>
                       <select name="city" style="width:292px" onchange="get_cities(this.value)">
					   <option value="none" selected="selected">Select City</option>
						<option value="London">London</option></select><?php echo form_error('city'); ?>
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
												
				<tr>
                    <th>Place </th>
                    <td>
                       <select name="place" id="place" style="width:292px">
						<option value="none" selected="selected">No Place</option>	
						</select>
						<?php echo form_error('place'); ?>		
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
				
				<tr>
                    <th>Photographer Name </th>
                    <td>
                       		<input class="clsTextBox" size="30" type="text" name="photo_grapher_name" id="photo_grapher_name" value=""><?php echo form_error('photo_grapher_name'); ?>	
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
				
				<tr>
                    <th>Photographer Website Url </th>
                    <td>
                       		<input class="clsTextBox" size="30" type="text" name="photo_grapher_web" id="photo_grapher_web" value=""><?php echo form_error('photo_grapher_web'); ?>	
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
				
				<tr>
                    <th>Description of Photographer</th>
                    <td>
                       		<textarea class="clsTextBox" name="photo_grapher_desc" id="photo_grapher_desc" value="" style="height: 162px; width: 282px;"></textarea>
							<?php echo form_error('photo_grapher_desc'); ?>
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
				
				<tr>
                    <th>Photographer Image</th>
                    <td>
                       		<input id="photo_grapher_image" name="photo_grapher_image" size="24" type="file">
							<?php echo form_error('photo_grapher_image'); ?>	
                    </td>
				</tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
				
				<tr>
                    <th>Is Featured</th>
                    <td>
                       		<select name="is_featured" id="is_featured">
							<option value="0"> No </option>
							<option value="1"> Yes </option>
							</select> 
                    </td>
				</tr>
					
				<tr>
				<td>&nbsp;</td>
				</tr>
		
				<tr>
                    <th>&nbsp;</th>
                    <td valign="top">
						<input type="submit" value="Add Photographer" name="save" class="buttonBlue">
                        <input type="reset" value="Cancel" name="yt1" class="buttonGreen cancel">
                    </td>
                </tr>
            </tbody>
        </table>
       </div>
    </form>