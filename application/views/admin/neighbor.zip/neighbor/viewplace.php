<form name="test" id="filter" action="" method="post">
<table cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-left: 10px; margin-bottom: 5px;">
        <tbody>
            <tr>
                <?php if(common::check_permission("add","neighbourhoods")){?>
                 <td align="left" colspan="4">
                     <a href="<?=site_url('neighbourhoods/addplace')?>"><img border="0" align="absmiddle" alt="#" src="<?=base_url()?>images/add.gif.png"></a>
                     &nbsp;
                     <a href="<?=site_url('neighbourhoods/addplace')?>">Add Neighborhood Places</a>
                 </td>
                 <?php }?>
                <td colspan="3" align="right" style="padding-right:10px">
                     
	  					<select name="country" id="country" onchange="show()">
						  <option value="">Select Country</option>
						  <?php
						  $country= $this->db->query("SELECT distinct(country) FROM `neighbor_city`");
						  $results=$country->result_array();
						  foreach ($results as $country)
						  {
								?><option value="<?php echo $country['country']; ?>"><?php echo $country['country']; ?></option>		<?php  
						  }
						  ?>
						  </select>
			   </td>
			   <td colspan="3" align="right" style="padding-right:10px">
						  <select name="state" id="state" onchange="show1()">
						   <option value="">Select state</option>
						  </select>
				 </td>
				 <td colspan="3" align="right" style="padding-right:10px">
						  <select name="city" id="city" >
						   <option value="">Select City</option>
						  </select>	
						  <input type="submit" id="submit" name="submit" value="Filter"/>
						  
                 </td>
                 
                  
            </tr>
        </tbody>
</table>
</form>
				<table cellspacing="0" cellpadding="0" border="0" width="100%" summary="Employee Pay Sheet" id="box-table-a">
				<tbody>
				<?php if($msg = $this->session->flashdata('flash_message'))
				{?>
				<tr>
					<td colspan="4" align="left" style="color:green" class="msg">
						<?php
							
								echo $msg;
						?>		
					</td>
				</tr>
				<?php }?>
				<?php	
				if(!isset($_POST['submit']) )
				{?>	
				<tr>
                <th width="12%" scope="col"><input type="checkbox" onclick="checkAll(this.checked,<?=count($area)?>)" id="allbox" name="allbox"></th>
				<th width="14%" scope="col">Sl.No.</th>
				<th width="14%" scope="col">Country</th>
				<th width="16%" scope="col">State</th>
				<th width="14%" scope="col">City</th>
				<th width="16%" scope="col">Areas</th>
				<th width="14%" scope="col">Action</th>
        
					<?php $i=1;
						echo count($area);
						if(isset($area) and count($area) > 0)
						{  
							$k=0;
							foreach($area->result() as $page)
							{
							
					?>
					
			 <tr>
			  <td><input type="checkbox" value="" id="checkbox_<?=$k?>" name="checkbox_<?=$k?>"></td>
			  <td><?php echo $i++;?></td>
			  <?php 
			  $train= $this->db->query("SELECT * FROM `neighbor_city` WHERE `id` = '".$page->city_id."'");
				  $results=$train->result_array();
				  
				  foreach ($results as $arrival)
				  {
 						$country = $arrival['Country'];
						$state = $arrival['State'];
						$city = $arrival['city']; 						
 				   }			  
			  ?>					  			  
			  <td><?php echo $country; ?></td>
			  <td><?php echo $state; ?></td>
			  <td><?php echo $city; ?></td>
			  <td><?php echo $page->area; ?></td>
			  <td><a class="edit_icon" href="<?php echo site_url('neighbourhoods/editplace/'.$page->id)?>" title="Edit"></a>
			      <a class="delete2_icon" href="<?php echo site_url('neighbourhoods/deleteplace/'.$page->id)?>" title="Delete" onclick="return confirm('Are you sure want to delete??');"></a>
			  </td>
        	</tr>
			
   <?php
   				$k++;
				}//Foreach End
			}//If End
			else
			{?>
			
			 <tr>
				<td colspan="6" align="center">
					No data found.
				</td>
			</tr> 
		<?php 	}
		?>
			
    <tr>
                            <td align="right" colspan="4"><?php if($pagination_links){?>Go to page:<?php }?>
                              <ul class="yiiPager" id="yw0">
                                 <?php echo $pagination_links;?>
                                    </ul>
                            </td>
                        </tr>
                </tbody>
</table>

<?php
}
else
{

		if($_POST['city']!="" && $_POST['country']!="" && $_POST['state']!="")
		{
 				  $trains= $this->db->query("SELECT * FROM `neighbor_city` WHERE `city` = '".$_POST['city']."'");
				  $result=$trains->result_array();
				  foreach ($result as $arrival)
				  {
				  $cityid=$arrival['id'];
				  }
?>
				<tr>
                <th width="12%" scope="col"><input type="checkbox" onclick="checkAll(this.checked,<?=count($area)?>)" id="allbox" name="allbox"></th>
				<th width="14%" scope="col">Sl.No.</th>
				<th width="14%" scope="col">Country</th>
				<th width="16%" scope="col">State</th>
				<th width="14%" scope="col">City</th>
				<th width="16%" scope="col">Areas</th>
				<th width="14%" scope="col">Action</th>
        
					<?php $i=1;
						if(isset($area) and count($area) > 0)
						{  
							$k=0;
							foreach($area as $page)
							{
							if($page->city_id==$cityid)
							{
					?>
					
			 <tr>
			  <td><input type="checkbox" value="" id="checkbox_<?=$k?>" name="checkbox_<?=$k?>"></td>
			  <td><?php echo $i++;?></td>
			  <?php 
			  $train= $this->db->query("SELECT * FROM `neighbor_city` WHERE `id` = '".$page->city_id."'");
				  $results=$train->result_array();
				  foreach ($results as $arrival)
				  {
 						$country = $arrival['Country'];
						$state = $arrival['State'];
						$city = $arrival['city']; 						
 				   }			  
			  ?>					  			  
			  <td><?php echo $country; ?></td>
			  <td><?php echo $state; ?></td>
			  <td><?php echo $city; ?></td>
			  <td><?php echo $page->area; ?></td>
			  <td><a href="<?php echo site_url('neighbourhoods/editplace/'.$page->id)?>">
                <img src="<?php echo base_url()?>images/edit-new.png" alt="Edit" title="Edit" /></a>
			      <a href="<?php echo site_url('neighbourhoods/deleteplace/'.$page->id)?>" onclick="return confirm('Are you sure want to delete??');"><img src="<?php echo base_url()?>images/Delete.png" alt="Delete" title="Delete" /></a>
			  </td>
        	</tr>
			
   <?php			
   					$k++;
   					}
				}//Foreach End
			}//If End
			else
			{?>
			
			 <tr>
				<td colspan="6" align="center">
					No data found.
				</td>
			</tr> 
		<?php 	}
		?>
			
    <tr>
                            <td align="right" colspan="4"><?php if($pagination_links){?>Go to page:<?php }?>
                              <ul class="yiiPager" id="yw0">
                                 <?php echo $pagination_links;?>
                                    </ul>
                            </td>
                        </tr>
                </tbody>
</table>

<?php
}

else
{


?>

<tr>
                <th width="12%" scope="col"><input type="checkbox" onclick="checkAll(this.checked,<?=count($area)?>)" id="allbox" name="allbox"></th>
				<th width="14%" scope="col">Sl.No.</th>
				<th width="14%" scope="col">Country</th>
				<th width="16%" scope="col">State</th>
				<th width="14%" scope="col">City</th>
				<th width="16%" scope="col">Areas</th>
				<th width="14%" scope="col">Action</th>
        
					<?php $i=1;
						if(isset($area) and count($area) > 0)
						{  
							$k=0;
							foreach($area as $page)
							{
							
					?>
					
			 <tr>
			  <td><input type="checkbox" value="" id="checkbox_<?=$k?>" name="checkbox_<?=$k?>"></td>
			  <td><?php echo $i++;?></td>
			  <?php 
			  $train= $this->db->query("SELECT * FROM `neighbor_city` WHERE `id` = '".$page->city_id."'");
				  $results=$train->result_array();
				  foreach ($results as $arrival)
				  {
 						$country = $arrival['Country'];
						$state = $arrival['State'];
						$city = $arrival['city']; 						
 				   }			  
			  ?>					  			  
			  <td><?php echo $country; ?></td>
			  <td><?php echo $state; ?></td>
			  <td><?php echo $city; ?></td>
			  <td><?php echo $page->area; ?></td>
			  <td><a href="<?php echo site_url('neighbourhoods/editplace/'.$page->id)?>">
                <img src="<?php echo base_url()?>images/edit-new.png" alt="Edit" title="Edit" /></a>
			      <a href="<?php echo site_url('neighbourhoods/deleteplace/'.$page->id)?>" onclick="return confirm('Are you sure want to delete??');"><img src="<?php echo base_url()?>images/Delete.png" alt="Delete" title="Delete" /></a>
			  </td>
        	</tr>
			
   <?php
   				$k++;
				}//Foreach End
			}//If End
			else
			{?>
			
			 <tr>
				<td colspan="6" align="center">
					No data found.
				</td>
			</tr> 
		<?php 	}
		?>
			
    <tr>
                            <td align="right" colspan="4"><?php if($pagination_links){?>Go to page:<?php }?>
                              <ul class="yiiPager" id="yw0">
                                 <?php echo $pagination_links;?>
                                    </ul>
                            </td>
                        </tr>
                </tbody>
</table>

<script>alert("Please select all category");</script>
<?php
	
}
}

?>
<SCRIPT LANGUAGE="JavaScript">
 $(document).ready(function() {
  // Handler for .ready() called.
  $(".Blck_Butt").click(function() {
	var confirmation =confirm('Are you sure you wants to delete ?');
		if (confirmation==true) {
		 return true;
		   } else {
		  return false;
		}});
	});  
	function show()
	{
		var country = document.getElementById('country').value;
		var dataString = "country=" + country ;
		var combo = document.getElementById("state");

		b_url = "<?php echo base_url().'neighbourhoods/selectbox'?>";
		$.ajax({
		type: "GET",
		url: b_url,
		data: dataString,
			success: function(data){
				combo.options.length = 0;	
				var option = document.createElement("option");
				option.text="select";
				option.value="";
				try {
					combo.add(option, null); 
				}catch(error) {
					combo.add(option); 
				}
				var split = data.split(',');
				var i;
				for(i=0;i<split.length-1;i++ )
				{
					var option = document.createElement("option");
					option.text = split[i];
					option.value = split[i];
					try {
						combo.add(option, null); 
					}catch(error) {
						combo.add(option); 
					}
				}
			}
		});
	}
   
	function show1()
	{
		var state = document.getElementById('state').value;
		var dataString = "state=" + state ;
		var combo = document.getElementById("city");

		b_url = "<?php echo base_url().'neighbourhoods/selectbox1'?>";
		$.ajax({
		type: "GET",
		url: b_url,
		data: dataString,
		success: function(data){


			combo.options.length = 0;	
			var option = document.createElement("option");
			option.text="select";
			option.value="";
			try {
				combo.add(option, null); 
			}catch(error) {
				combo.add(option); 
			}
			var split = data.split(',');
			var i;
			for(i=0;i<split.length-1;i++ )
			{
				var option = document.createElement("option");
				option.text = split[i];
				option.value = split[i];
				try {
					combo.add(option, null); 
				}catch(error) {
					combo.add(option); 
				}
			}
		}	
		});

	}
   
   
	function show2()
	{
	setTimeout('document.test.submit()',5000);
	//document.getElementById('filter').submit();
	}   
   </script>