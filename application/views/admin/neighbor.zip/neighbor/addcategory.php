<?php if($msg!=''): echo '<div class="success">'.$msg.'</div>'; endif;?>
    <form method='post' action=''>
       <div id="add_form"> 
		<?php
			//Show Flash Message
			if($msg = $this->session->flashdata('flash_message'))
			{
				echo $msg;
			}
		?>		
		<table cellpadding="5" cellspacing="5">
            <tbody>
			<tr>
				<th>Add Neighborhood Category:</th>
			</tr>
			
                <tr>
                    <th>Category </th>
                    <td>
                       <input class="clsTextBox" size="30" type="category" name="category" id="category" value="">
						<?php echo form_error('category'); ?>	
                    </td>
                </tr>
				
				
				
				<tr>
				<td>&nbsp;</td>
				</tr>
		
				<tr>
                    <th>&nbsp;</th>
                    <td valign="top">
						<input type="submit" value="Add Category" name="save" class="buttonBlue">
                        <input type="reset" value="Cancel" name="yt1" class="buttonGreen cancel">
                    </td>
                </tr>
            </tbody>
        </table>
       </div>
    </form>