<?php if($msg!=''): echo '<div class="success">'.$msg.'</div>'; endif;?>
    <form method='post' action='<?=$action;?>' enctype="multipart/form-data">
       <div id="add_form"> 
		<?php
			//Show Flash Message
			if($msg = $this->session->flashdata('flash_message'))
			{
				echo $msg;
			}
		?>		
		<table cellpadding="5" cellspacing="5">
            <tbody>
			<tr>
				<th>Edit Neighborhood Category:</th>
			</tr>
			
                <tr>
                    <th>Category</th>
                    <td>
                       <textarea class="clsTextBox" name="category" id="category" value="" style="height: 162px; width: 282px;"><?php echo $list->category_name?></textarea>
				<?php echo form_error('category'); ?>		
                    </td>
                </tr>
				
								
				<tr>
				<td>&nbsp;</td>
				</tr>
		
				<tr>
                    <th>&nbsp;</th>
                    <td valign="top">
						<input type="submit" value="Save" name="edit" class="buttonBlue">
                        <input type="reset" value="Cancel" name="yt1" class="buttonGreen cancel">
                    </td>
                </tr>
            </tbody>
        </table>
       </div>
    </form>