<!--Listing -->
<style type="text/css">
    .settings-block {
        width: 170px;
        height: 110px;
        float: left;
        margin: 5px;
        cursor: pointer;
        background: url('images/icon/icn_settings.png') 0 0 no-repeat;
    }
    .settings-block a {
        text-decoration: none;
    }
    .settings-block > div {
        color: #000000;
        font-size: 13px;
        margin: 5px 10px;
    }
    .settings-block.with-notifications_menu_item {
        background-position: -850px 0px;
    }
    .settings-block.with-notifications_menu_item:hover {
        background-position: -850px -110px;
    }

    .settings-block.with-mail_list_menu_item:hover {
        background-position: -1530px -110px;
    }
    .settings-block.with-mail_list_menu_item {
        background-position: -1530px 0;
    }
    .settings-block.with-countries_menu_item {
        background-position: -340px 0px;
    }
    .settings-block.with-countries_menu_item:hover {
        background-position: -340px -110px;
    }
    .settings-block h6 {
        color: #000000;
        font-weight: bold;
        font-size: 13px;
        margin: 5px 10px;
        padding: 0;
    }
</style>
<table cellspacing="0" cellpadding="0" border="0" width="100%" summary="Employee Pay Sheet" id="box-table-a">
    <tbody>

    <div class="settings-block with-mail_list_menu_item" onclick="javascript: location.href='<?=site_url('neighbourhoods/viewcity')?>';">
        <a href="<?=site_url('neighbourhoods/viewcity')?>"><h6>Cities</h6></a>
        <div>Cities</div>
    </div>

    <div class="settings-block with-notifications_menu_item" onclick="javascript: location.href='<?=site_url('neighbourhoods/viewplace')?>';">
        <a href="<?=site_url('neighbourhoods/viewplace')?>"><h6>Places</h6></a>
        <div>Places</div>
    </div>


    <div class="settings-block with-countries_menu_item" onclick="javascript: location.href='<?=site_url('neighbourhoods/viewcategory')?>';">
        <a href="<?=site_url('neighbourhoods/viewcategory')?>"><h6>Categories</h6></a>
        <div>Categories</div>
    </div>

    <div class="settings-block with-countries_menu_item" onclick="javascript: location.href='<?=site_url('neighbourhoods/viewpost')?>';">
        <a href="<?=site_url('neighbourhoods/viewpost')?>"><h6>Posts</h6></a>
        <div>Posts</div>
    </div>

    <div class="settings-block with-countries_menu_item" onclick="javascript: location.href='<?=site_url('neighbourhoods/viewphotographer')?>';">
        <a href="<?=site_url('neighbourhoods/viewphotographer')?>"><h6>Photographers</h6></a>
        <div>Photographers</div>
    </div>

    <div class="settings-block with-countries_menu_item" onclick="javascript: location.href='<?=site_url('neighbourhoods/viewtag')?>';">
        <a href="<?=site_url('neighbourhoods/viewtag')?>"><h6>Tags</h6></a>
        <div>Tags</div>
    </div>

    <div class="settings-block with-countries_menu_item" onclick="javascript: location.href='<?=site_url('neighbourhoods/viewknowledge')?>';">
        <a href="<?=site_url('neighbourhoods/viewknowledge')?>"><h6>Local Knowledge</h6></a>
        <div>Local Knowledge</div>
    </div>

    </tbody>
</table>