<?php if($msg!=''): echo '<div class="success">'.$msg.'</div>'; endif;?>
    <form method='post' action=''>
       <div id="add_form"> 
		<?php
			//Show Flash Message
			if($msg = $this->session->flashdata('flash_message'))
			{
				echo $msg;
			}
		?>		
		<table cellpadding="5" cellspacing="5">
            <tbody>
			<tr>
				<th>Add_Neighborhood_Knowledge:</th>
			</tr>
			
                <tr>
                    <th>Knowledge </th>
                    <td>
                       <textarea class="clsTextBox" name="knowledge" id="knowledge" value="" style="height: 162px; width: 282px;"><?php echo $list->knowledge;?></textarea>
						<?php echo form_error('knowledge'); ?>	
                    </td>
                </tr>
				
				<tr>
                    <th>City </th>
                    <td>
                       <select name="city" id="city" style="width:292px" onchange="get_cities(this.value)">
						<option value="none" selected="selected">Select City</option>
						<option value="London">London</option></select>	
						<?php echo form_error('city'); ?>		
                    </td>
                </tr>
				
				<tr>
                    <th>Place </th>
                    <td>
                       <select name="place" id="place" style="width:292px">
						<option value="none" selected="selected">No Place</option>	
						</select>
						<?php echo form_error('place'); ?>		
                    </td>
                </tr>
				
				<tr>
                    <th>Is Shown </th>
                    <td>
                       		<select name="is_shown" id="is_shown">
							<option value="1"> Yes </option>
							<option value="0"> No </option>
							</select>  
							<?php echo form_error('is_shown'); ?>		
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
		
				<tr>
                    <th>&nbsp;</th>
                    <td valign="top">
						<input type="submit" value="Edit Knowledge" name="edit" class="buttonBlue">
                        <input type="reset" value="Cancel" name="yt1" class="buttonGreen cancel">
                    </td>
                </tr>
            </tbody>
        </table>
       </div>
    </form>