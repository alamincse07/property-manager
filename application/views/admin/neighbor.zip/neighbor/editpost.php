<?php if($msg!=''): echo '<div class="success">'.$msg.'</div>'; endif;?>
    <form method='post' action='' enctype="multipart/form-data">
       <div id="add_form"> 
		<?php
			//Show Flash Message
			if($msg = $this->session->flashdata('flash_message'))
			{
				echo $msg;
			}
		?>		
		<table cellpadding="5" cellspacing="5">
            <tbody>
			<tr>
				<th>Edit Neighborhood Post:</th>
			</tr>
				<tr>
                    <th>Post </th>
                    <td>
                       		<textarea class="clsTextBox" name="title" id="title" value="" style="height: 162px; width: 282px;"><?php echo $list->title?></textarea>
							<?php echo form_error('title'); ?>
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
				
                <tr>
                    <th>City</th>
                    <td>
                       <select name="city" style="width:292px" onchange="get_cities(this.value)">
					   <option value="none" selected="selected">Select City</option>
						<option value="London">London</option></select><?php echo form_error('city'); ?>
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
												
				<tr>
                    <th>Place </th>
                    <td>
                       <select name="place" id="place" style="width:292px">
						<option value="none" selected="selected">No Place</option>	
						</select>
						<?php echo form_error('place'); ?>		
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
				
				
				<tr>
                    <th>Description</th>
                    <td>
                       		<textarea class="clsTextBox" name="description" id="description" value="" style="height: 162px; width: 282px;"><?php echo $list->description?></textarea>
							<?php echo form_error('description'); ?>	
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
				
								
				<tr>
                    <th>Is Featured</th>
                    <td>
                       		<select name="is_featured" id="is_featured">
							<option value="0"> No </option>
							<option value="1"> Yes </option>
							</select> 
                    </td>
				</tr>
					
				<tr>
				<td>&nbsp;</td>
				</tr>
		
				<tr>
                    <th>&nbsp;</th>
                    <td valign="top">
						<input type="submit" value="Edit Post" name="edit" class="buttonBlue">
                        <input type="reset" value="Cancel" name="yt1" class="buttonGreen cancel">
                    </td>
                </tr>
            </tbody>
        </table>
       </div>
    </form>