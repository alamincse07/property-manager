<?php if($msg!=''): echo '<div class="success">'.$msg.'</div>'; endif;?>
    <form method='post' action=''>
       <div id="add_form"> 
		<?php
			//Show Flash Message
			if($msg = $this->session->flashdata('flash_message'))
			{
				echo $msg;
			}
			
		?>	
		<?php
	  	//Content of a group
		if(isset($places) and count($places)>0)
		{
			$page = $places->row();
			
	  	?>	
		<table cellpadding="5" cellspacing="5">
            <tbody>
			<tr>
				<th>Edit Neighborhood Places:</th>
			</tr>
			
                <tr>
                    <th>Area Name </th>
                    <td>
                       <input class="" type="text" name="area" id="area" value="<?php echo $page->area; ?>">
                    </td>
                </tr>
				
				
				<tr>
				<td>&nbsp;</td>
				</tr>
		
				<tr>
                    <th>&nbsp;</th>
                    <td valign="top">
						<input type="submit" value="Edit Place" name="edit" class="buttonBlue">
                        <input type="reset" value="Cancel" name="yt1" class="buttonGreen cancel">
                    </td>
                </tr>
            </tbody>
        </table>
       </div>
    </form>
	<?php }?>