<?php if($msg!=''): echo '<div class="success">'.$msg.'</div>'; endif;?>
    <form method='post' action='<?=$action;?>' enctype="multipart/form-data">
       <div id="add_form"> 
		<?php
			//Show Flash Message
			if($msg = $this->session->flashdata('flash_message'))
			{
				echo $msg;
			}
		?>		
		<table cellpadding="5" cellspacing="5">
            <tbody>
			<tr>
				<th>Edit Neighborhood City:</th>
			</tr>
			
                <tr>
                    <th>ciudad </th>
                    <td>
                       <input class="clsTextBox" size="30" type="text" name="city" id="city" value="<?php echo $list->city ?>">
				<?php echo form_error('city'); ?>	
                    </td>
                </tr>
				
				<tr>
                    <th>City Description </th>
                    <td>
                      <textarea class="clsTextBox" name="city_desc" id="city_desc" value="" style="height: 162px; width: 282px;"><?php echo $list->city_desc ?></textarea>
					  <?php echo form_error('city_desc'); ?>	
                    </td>
                </tr>
				
				<tr>
                    <th>Known For </th>
                    <td>
                      <textarea class="clsTextBox" name="known" id="known" value="" style="height: 162px; width: 282px;"><?php echo $list->known ?></textarea>
					  <span style="color:#9c9c9c; text-style:italic; font-size:11px;">Ex: Hollywood,boardwalks.</span>
					  <?php echo form_error('known'); ?>	
                    </td>
                </tr>
				
				<tr>
                    <th>Get around with </th>
                    <td>
                      <input class="clsTextBox" size="30" type="text" name="around" id="around" value="<?php echo $list->around ?>">
					  <span style="color:#9c9c9c; text-style:italic; font-size:11px;">Ex: Car,Public Transit</span>
					  <?php echo form_error('around'); ?>	
                    </td>
                </tr>
				
				<!--<tr>
                    <th>City Image </th>
                    <td>
                      <input id="city_image" name="city_image" size="24" type="file">
					  <span style="color:#9c9c9c; text-style:italic; font-size:11px; padding:33px;">Resolution: 1425x500</span>
                    </td>
                </tr>-->
				
				<tr>
                    <th>Is Home? </th>
                    <td>
                     <select name="is_home" id="is_home">
					 <option value="0" <?php if($list->is_home==0) echo "selected='selected'" ?>> No </option>
					 <option value="1" <?php if($list->is_home==1) echo "selected='selected'" ?>> Yes </option>
					 </select> 
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
		
				<tr>
                    <th>&nbsp;</th>
                    <td valign="top">
						<input type="submit" value="Save" name="edit" class="buttonBlue">
                        <input type="reset" value="Cancel" name="yt1" class="buttonGreen cancel">
                    </td>
                </tr>
            </tbody>
        </table>
       </div>
    </form>