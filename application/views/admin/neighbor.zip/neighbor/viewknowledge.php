<form action="" method="POST">
<table cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-left: 10px; margin-bottom: 5px;">
        <tbody>
            <tr>
                <?php if(common::check_permission("add","neighbourhoods")){?>
                 <td align="left" colspan="4">
                     <a href="<?=site_url('neighbourhoods/addknowledge')?>"><img border="0" align="absmiddle" alt="#" src="<?=base_url()?>images/add.gif.png"></a>
                     &nbsp;
                     <a href="<?=site_url('neighbourhoods/addknowledge')?>">Add Knowledge</a>
                 </td>
                 <?php }?>
                 <!--<td colspan="3" align="right" style="padding-right:10px">
                     <b>Category</b>
                     <select name="category_id" class="select_box">
                         <option value="">-Select-</option>
                         <?php //echo $category_list;?>

                     </select>
                 </td>-->
                  
            </tr>
        </tbody>
</table>
</form>
				<table cellspacing="0" cellpadding="0" border="0" width="100%" summary="Employee Pay Sheet" id="box-table-a">
				<tbody>
				<?php if($msg){?>
				<tr>
					<td colspan="4" align="left" style="color:green" class="msg">
						<?php echo $msg;?>
					</td>
				</tr>
				<?php }?>
				<tr>
                <th width="14%" scope="col"><input type="checkbox" onclick="checkAll(this.checked,<?=count($list)?>)" id="allbox" name="allbox"></th>
				<th width="14%" scope="col">Sl.No.</th>
				<th width="16%" scope="col">Knowledge</th>
				<th width="14%" scope="col">City</th>
				<th width="14%" scope="col">Place</th>
				<th width="14%" scope="col">Is Show</th>
				<th width="14%" scope="col">Action</th>
        
					<?php $i=1;
						if(isset($list) and count($list) > 0)
						{  
							$k=0;
							foreach($list as $page)
							{
							
					?>
					
			 <tr>
			  <td><input type="checkbox" value="" id="checkbox_<?=$k?>" name="checkbox_<?=$k?>"></td>
			  <td><?php echo $i++;?></td>					  			  
			 <td><?php echo $page->knowledge; ?></td>
			  <td><?php echo $page->city; ?></td>
			  <td><?php echo $page->place; ?></td>	
			  <td><?php echo ($page->is_shown==1) ? 'yes' :'No'; ?></td>
			  <td><a class="edit_icon" href="<?php echo site_url('neighbourhoods/editknowledge/'.$page->id)?>" title="Edit"></a>
			      <a class="delete2_icon" href="<?php echo site_url('neighbourhoods/deleteknowledge/'.$page->id)?>" title="Delete" onclick="return confirm('Are you sure want to delete??');"></a>
			  </td>
        	</tr>
			
   <?php
   				$k++;
				}//Foreach End
			}//If End
			else
			{?>
			
			 <tr>
				<td colspan="5" align="center">
					No data found.
				</td>
			</tr> 
		<?php 	}
		?>
			
    <tr>
                            <td align="right" colspan="4"><?php if($pagination_links){?>Go to page:<?php }?>
                              <ul class="yiiPager" id="yw0">
                                 <?php echo $pagination_links;?>
                                    </ul>
                            </td>
                        </tr>
                </tbody>
</table>