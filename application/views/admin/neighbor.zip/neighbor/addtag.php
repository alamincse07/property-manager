<?php if($msg!=''): echo '<div class="success">'.$msg.'</div>'; endif;?>
    <form method='post' action=''>
       <div id="add_form"> 
		<?php
			//Show Flash Message
			if($msg = $this->session->flashdata('flash_message'))
			{
				echo $msg;
			}
		?>		
		<table cellpadding="5" cellspacing="5">
            <tbody>
			<tr>
				<th>Add Neighborhood Tag:</th>
			</tr>
			
                <tr>
                    <th>Tag </th>
                    <td>
                       <input class="clsTextBox" size="30" type="text" name="tag" id="tag" value="">
						<?php echo form_error('tag'); ?>		
                    </td>
                </tr>
				
				 <tr>
                    <th>ciudad </th>
                    <td>
                       <select name="city" id="city" style="width:292px" onchange="get_cities(this.value)">
						<option value="" selected="selected">Select City</option>
						<option value="London">London</option></select>
						<?php echo form_error('city'); ?>			
                    </td>
                </tr>
				
				<tr>
                    <th>Place </th>
                    <td>
                       <select name="place" id="place" style="width:292px">
						<option value="none" selected="selected">No Place</option>	
						</select>		
                    </td>
                </tr>
				
				<tr>
                    <th>Is Shown </th>
                    <td>
                       <select name="is_shown" id="is_shown">
						<option value="1"> Yes </option>
						<option value="0"> No </option>
						</select> 	
                    </td>
                </tr>
				
				<tr>
				<td>&nbsp;</td>
				</tr>
		
				<tr>
                    <th>&nbsp;</th>
                    <td valign="top">
						<input type="submit" value="Add Tag" name="save" class="buttonBlue">
                        <input type="reset" value="Cancel" name="yt1" class="buttonGreen cancel">
                    </td>
                </tr>
            </tbody>
        </table>
       </div>
    </form>